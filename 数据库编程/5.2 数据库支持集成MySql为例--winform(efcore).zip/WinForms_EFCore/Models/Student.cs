﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinForms_EFCore.Models
{
    [Table("Student")] //注解、特性
    public class Student
    {
        [Key]
        public String StuNo { get; set; }

        public String StuName { get; set; }

        public String Sex { get; set; }

        public DateTime? Birthday { get; set; }
    }
}
