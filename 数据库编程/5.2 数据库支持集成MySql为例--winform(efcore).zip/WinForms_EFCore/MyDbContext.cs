﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace WinForms_EFCore
{
    public class MyDbContext : DbContext
    {
        public DbSet<Models.Student> Students { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            String connString = ConfigurationManager.ConnectionStrings["Default"].ToString();
            optionsBuilder.UseMySql(connString);
        }
    }
}
