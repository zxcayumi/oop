﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms_EFCore
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Models.Student stu = new Models.Student();
            stu.StuNo = txtStuNo.Text;
            stu.StuName = txtStuName.Text;
            stu.Sex = cmbSex.Text;
            stu.Birthday = dtpBirthday.Value;

            using (MyDbContext context = new MyDbContext())
            {
                context.Add(stu);
                context.SaveChanges();
                MessageBox.Show("添加成功！");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbSex.SelectedIndex = 0;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (MyDbContext context = new MyDbContext())
            {
                IQueryable<Models.Student> result =
                    context.Students.Where(s => s.StuName.Contains(txtKeywords.Text));

                dataGridView1.DataSource = result.ToList();
            }
        }
    }
}
