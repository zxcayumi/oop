﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB.Sample3
{
    /*
     * Lambda本质：
     * 1.不是委托，委托的实例（C#语法来看可以把它看作是匿名方法，
     * 但通过IL分析，它本质上并不是匿名函数）
     * 2.它是方法，可以和委托绑定（可以被委托包装）
     * 
     * 语法：gose to
     * 参数列表 => 方法体
     */
    public delegate void MethodDelegate1();
    public delegate void MethodDelegate2(int x,int y);

    public delegate int MethodDelegate3(int x, int y);


    public class LambdaTest
    {
        //2.0
        MethodDelegate1 m1 = new MethodDelegate1(delegate() {
            Console.WriteLine("Hello World!");
        });

        //3.0
        MethodDelegate1 m2 = new MethodDelegate1(() => {
            Console.WriteLine("Hello"); 
        });

        MethodDelegate1 m3 = () => {
            Console.WriteLine("Hello");
        };

        MethodDelegate2 md1 = new MethodDelegate2(delegate(int x,int y) {
            Console.WriteLine($"{x * y}");
        });

        MethodDelegate2 md2 = new MethodDelegate2((int x,int y) => {
            Console.WriteLine($"{x * y}");
        });

        MethodDelegate2 md3 = new MethodDelegate2((x, y) => {
            Console.WriteLine($"{x * y}");
        });

        MethodDelegate2 md4 = (x, y) => {
            Console.WriteLine($"{x * y}");
        };

        //如果lambda只有一条语句的话，可以不用大括号
        MethodDelegate2 md5 = (x, y) => Console.WriteLine($"{x * y}");

        //如果lambda只有一条语句的话，可以不用大括号，并且可以省略return
        MethodDelegate3 md6 = (x, y) => x * y;

        //Action,Func
        Action a = () => Console.WriteLine("This is a test!");
        Action<String> a1 = (name) => Console.WriteLine($"{name},Hello");
        Action<String> a2 = name => Console.WriteLine($"{name},Hello");

        Func<DateTime, DayOfWeek> f = d => d.DayOfWeek;
    }
}
