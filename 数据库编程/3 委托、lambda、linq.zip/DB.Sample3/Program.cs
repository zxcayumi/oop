﻿using System;

namespace DB.Sample3
{
    class Program
    {
        static void Main(string[] args)
        {
            //DelegateTest d = new DelegateTest();
            //d.Test0();
            //d.Test1();
            //d.Test2();
            //d.Test3();
            //d.Test4();
            //d.Test5();
            //d.Test6();

            DelegateTest1 d = new DelegateTest1();
            d.Test();
        }
    }
}
