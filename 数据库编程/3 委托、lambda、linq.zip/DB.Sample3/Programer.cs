﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB.Sample3
{
    public class Programer
    {
        public void Code()
        {
            Console.WriteLine("编代码...");
        }
    }
}
