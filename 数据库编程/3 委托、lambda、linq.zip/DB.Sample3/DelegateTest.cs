﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB.Sample3
{
    //delegate委托
    //本质是什么？1.类类型，可以被实例化，继承子System.MulticastDelegate
    //2.内部有方法，可以被调用
    public class DelegateTest
    {
        #region 无参数无返回值
        //delegate的基本使用语法（无参数无返回值）
        public void SayHello()
        {
            Console.WriteLine("Hello World！");
        }

        //public delegate void MethodDelegate0();

        //委托执行测试
        public void Test0()
        {
            //MethodDelegate0 md = new MethodDelegate0(SayHello);
            //md.Invoke();//方式1
            //md();//方式2

            //方式3：无返回值的委托Action
            Action a = SayHello;
            a.Invoke();
        }
        #endregion

        #region 有参数无返回值
        //有参数无返回值
        public void SayHello(String name)
        {
            Console.WriteLine($"{name},Hello");
        }

        //public delegate void MethodDelegate1(String name);

        public void Test1()
        {
            //MethodDelegate1 md1 = new MethodDelegate1(SayHello);
            //MethodDelegate1 md1 = SayHello;
            //md1.Invoke("John");

            //最多可以支持16个参数
            Action<String> a = SayHello;
            a.Invoke("张三");
        }
        #endregion

        #region 有参数有返回值
        public int Sum(int a, int b)
        {
            return a + b;
        }

        //public delegate int MethodDelegate2(int a, int b);

        public void Test2()
        {
            //MethodDelegate2 md2 = Sum;//方法与委托绑定时，不要加小括号，只写方法名
            //int result = md2(2, 3);
            //Console.WriteLine(result);

            //有返回值的委托
            Func<int, int, int> f = Sum;
            int reuslt = f(3,6);
            Console.WriteLine(reuslt);
        }
        #endregion

        #region 多播委托
        public void ChineseSayHello()
        {
            Console.WriteLine("你好");
        }

        public void EnglishSayHello()
        {
            Console.WriteLine("Hello");
        }

        public delegate void SayHelloDelegate();

        public void Test3()
        {
            SayHelloDelegate sd = ChineseSayHello;
            sd += EnglishSayHello;

            sd.Invoke();//Invoke时，按照方法的添加顺序，以此执行函数
        }

        #endregion

        #region 多播委托的案例
        public void Test4()
        {
            //Programmer、Tester、Salesman
            //Monitor
            Monitor m = new Monitor();//监控老板的人员
            Programer p = new Programer();
            Programer p1 = new Programer();
            Tester t = new Tester();
            Salesman s = new Salesman();

            m.Notify += p.Code;
            m.Notify += p1.Code;
            m.Notify += t.Test;
            m.Notify += s.Sale;
            //m.Notify();//事件不能在Monitor类外面直接对委托调用，只能注册或反注册

            //m.Invoke();//发送通知
        }

        #endregion

        #region 委托的另一种形式：Action、Func、Predicate
        //无返回值Action
        //有返回值Func
        public DateTime GetDateTime()
        {
            return DateTime.Now;
        }

        public void Test5()
        {
            Func<DateTime> f = GetDateTime;
            var result = f.Invoke();
            Console.WriteLine(result);
        }

        //判断某天是否是星期一
        public bool IsMonday(DateTime dt)
        {
            return dt.DayOfWeek == DayOfWeek.Monday;
        }

        public void Test6()
        {
            //Func<DateTime, bool> f = IsMonday;
            //bool result = f.Invoke(DateTime.Now.AddDays(2));
            //Console.WriteLine(result);

            //Predicate，有1个入参，固定返回值是bool
            Predicate<DateTime> p = IsMonday;
            bool result = p.Invoke(DateTime.Now.AddDays(2));
            Console.WriteLine(result);
        }

        #endregion

    }
}
