﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB.Sample3
{
    public class DelegateTest1
    {
        private void ChineseSayHello()
        {
            Console.WriteLine("你好");
        }

        private void EnglishSayHello()
        {
            Console.WriteLine("Hello");
        }

        private void JapSayHello()
        {
            Console.WriteLine("kaoniqiwa");
        }

        //有新的国家人员加入的话，会导致对原有方法的代码改写（违反了开放封闭原则）
        //public void SayHi(String name, PType type)
        //{
        //    Console.WriteLine("log:begin sayhello");
        //    switch (type)
        //    {
        //        case PType.Chinese:
        //            ChineseSayHello();
        //            break;
        //        case PType.English:
        //            EnglishSayHello();
        //            break;
        //        case PType.Japnese:
        //            JapSayHello();
        //            break;
        //        default:
        //            break;
        //    }
        //    Console.WriteLine("log:end sayhello");
        //}

        public void SayHi(String name, Action a)
        {
            Console.WriteLine("log:begin sayhello");//不变逻辑
            //要执行的内容，但具体是谁执行不确定
            //通过委托把不确定的执行包装起来
            a.Invoke();
            Console.WriteLine("log:end sayhello");//不变逻辑
        }

        public void Test()
        {
            Action a = EnglishSayHello;
            SayHi("John",a);
            SayHi("张三", ChineseSayHello);
        }
    }

    public enum PType
    {
        Chinese,
        English,
        Japnese
    }
}
