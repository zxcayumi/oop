﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB.Sample3
{
    public class Salesman
    {
        public void Sale()
        {
            Console.WriteLine("联系客户...");
        }
    }
}
