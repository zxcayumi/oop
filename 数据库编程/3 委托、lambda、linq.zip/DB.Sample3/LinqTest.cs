﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB.Sample3
{
    //Linq:Language Integrated Query
    public class LinqTest
    {
        List<Student> students;

        public LinqTest()
        {
            students = new List<Student>()
            {
                new Student(){Name="张三",Sex="男",Age=18},
                new Student(){Name="张四",Sex="女",Age=14},
                new Student(){Name="张五",Sex="男",Age=19},
                new Student(){Name="张六",Sex="男",Age=22},
                new Student(){Name="张七",Sex="女",Age=26},
                new Student(){Name="张八",Sex="男",Age=30}
            };
        }

        public void Test()
        {
            //引入System.Linq后，List集合就有了Where等Linq查询方法
            //通过C#的扩展方法实现的
            var list = students.Where(s => s.Age > 20 && s.Sex =="男");

            //Linq to SQL,Expression二叉树的数据结构，层次化的结构
            var list1 = students.AsQueryable().Where(s => s.Age > 20 && s.Sex == "男");


        }
    }

    public class Student
    {
        public String Name { get; set; }
        public String Sex { get; set; }

        public int Age { get; set; }
    }
}
