﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB.Sample3
{
    public delegate void NotifyDelegate();

    public class Monitor
    {
        //event事件
        //在委托定义前加了个event关键字
        //event只能在类的内部直接被调用
        //而委托在当前类内部或类外部（其他类中）都可以被Invoke执行
        public event NotifyDelegate Notify;//包装方法，代理别的方法的执行

        //老板来的时候，通知大家
        public void Invoke()
        {
            if (Notify != null)
            {
                Notify.Invoke();//event只能在类的内部直接被调用
            }
        }        
    }
}
