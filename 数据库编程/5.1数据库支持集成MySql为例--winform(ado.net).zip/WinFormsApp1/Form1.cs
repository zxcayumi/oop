﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            String sql = "INSERT INTO Student(StuNo,StuName,Sex,Birthday) VALUE('00001','张三','男','2000-1-1')";

            String connString = ConfigurationManager.ConnectionStrings["Default"].ToString();

            try
            {
                //1.创建连接
                MySqlConnection conn = new MySqlConnection(connString);

                //2.打开连接
                conn.Open();

                //3.执行操作
                //3.1 Command创建
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                //3.2Command执行
                cmd.ExecuteNonQuery();

                //4.关闭连接
                conn.Close();
                MessageBox.Show("添加成功");
            }
            catch
            {
                MessageBox.Show("添加失败");
            }

        }
    }
}
