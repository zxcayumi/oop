﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace ConsoleApp2
{
    class Program
    {
        static SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

        static Program()
        {
            builder.DataSource = ".";//.代表当前ip
            builder.InitialCatalog = "Test";//要访问的数据库名
            builder.UserID = "sa";//登陆账号
            builder.Password = "as";//登陆密码
            builder.Pooling = true;//数据库连接池
        }


        static void Main(string[] args)
        {
            //ConnectionTest();
            //ConnectionTest1();
            //InsertTest();
            //UpdateTest();
            //SelectTest();
            //SelectTest1();
            SelectTest2();
        }

        //要想富，先修路
        public static void ConnectionTest()
        {
            String connString = "Data Source=.;Initial Catalog=Test;User ID=sa;Password=as;Pooling=False";
            //SqlConnection conn = new SqlConnection(connString);

            //try
            //{
            //    conn.Open();//打开道路
            //    Console.WriteLine("连接已打开");
            //    int a = 2;
            //    Console.WriteLine(a / 0);

            //    //具体干活
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            //finally
            //{
            //    conn.Close();//关闭道路
            //    Console.WriteLine("连接已关闭");
            //}

            using (SqlConnection conn = new SqlConnection(connString))//using生命周期结束时，connection会自动关闭
            {
                conn.Open();
                //操作数据库
            }

        }

        public static void ConnectionTest1()
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = ".";//.代表当前ip
            builder.InitialCatalog = "Test";//要访问的数据库名
            builder.UserID = "sa";//登陆账号
            builder.Password = "as";//登陆密码
            builder.Pooling = false;//数据库连接池

            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = builder.ConnectionString;
            conn.Open();
            Console.WriteLine("连接已打开");

            conn.Close();
            Console.WriteLine("连接已关闭");
        }

        //DML，实现增加、修改、删除
        //添加
        public static void InsertTest()
        {
            using (SqlConnection conn = new SqlConnection(builder.ConnectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "INSERT INTO Student(StuNo,StuName,Birthday) VALUES('00005','王五','1995-5-5')";
                int count = cmd.ExecuteNonQuery();
                Console.WriteLine("成功插入" + count + "条数据");
            }
        }

        //修改
        public static void UpdateTest()
        {
            using (SqlConnection conn = new SqlConnection(builder.ConnectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "UPDATE Student SET Birthday = '1978-10-19' WHERE StuNo = '00009'";
                int count = cmd.ExecuteNonQuery();
                Console.WriteLine("成功修改" + count + "条数据");
            }
        }

        //连接池的作用。批量插入10000数据
        public static void InsertTest1()
        {
            SqlConnection conn = new SqlConnection(builder.ConnectionString);

            string[] strs = new string[]{  "白","毕","卞","蔡","曹","岑","常","车","陈","成" ,"程","池","邓","丁","范","方","樊","费","冯","符"
           ,"傅","甘","高","葛","龚","古","关","郭","韩","何" ,"贺","洪","侯","胡","华","黄","霍","姬","简","江"
           ,"姜","蒋","金","康","柯","孔","赖","郎","乐","雷" ,"黎","李","连","廉","梁","廖","林","凌","刘","柳"
           ,"龙","卢","鲁","陆","路","吕","罗","骆","马","梅" ,"孟","莫","母","穆","倪","宁","欧","区","潘","彭"
           ,"蒲","皮","齐","戚","钱","强","秦","丘","邱","饶" ,"任","沈","盛","施","石","时","史","司徒","苏","孙"
           ,"谭","汤","唐","陶","田","童","涂","王","危","韦" ,"卫","魏","温","文","翁","巫","邬","吴","伍","武"
           ,"席","夏","萧","谢","辛","邢","徐","许","薛","严" ,"颜","杨","叶","易","殷","尤","于","余","俞","虞"
           ,"元","袁","岳","云","曾","詹","张","章","赵","郑" ,"钟","周","邹","朱","褚","庄","卓" };
            Random rd = new Random();
            //批量添加数据
            for (int i = 1; i < 10001; i++)
            {
                String stuNo = i.ToString().PadLeft(5, '0'); //1 --> 00001
                String birthday = "1999-10-10";
                String stuName = "";
                stuName += strs[rd.Next(0,strs.Length)];
                stuName += strs[rd.Next(0, strs.Length)];

                conn.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = $"INSERT INTO Student(StuNo,StuName,Birthday) VALUES('{stuNo}','{stuName}','{birthday}')";
                int count = cmd.ExecuteNonQuery();
                if (count > 0) Console.WriteLine("成功添加"+count + "条数据："+stuNo);

                conn.Close();
            }

        }

        //DQL--SELECT
        /// <summary>
        /// 一次性查询多条数据（SqlCommand自己不行了，配合搬运工SqlDataAdapter）
        /// </summary>
        public static void SelectTest()
        {
            SqlConnection conn = new SqlConnection(builder.ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "SELECT * FROM Student";
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);//adapter会自动管理conn的开关，不需要手动打开和关闭
            DataSet ds = new DataSet();//存数据的仓库
            adapter.Fill(ds);//adapter搬运数据回来，放到本地仓库（放到了DataSet里面的第0号DataTable）

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                Console.WriteLine(row["stuNo"].ToString() + "\t" + row["stuName"].ToString());
            }
        }

        //数据库连接一直保持连接状态，每次操作一条数据（不是一次性把所有数据都搬运到本地/内存）
        public static void SelectTest1()
        {
            SqlConnection conn = new SqlConnection(builder.ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "SELECT * FROM Student";

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())//Read一次，就指向下一条数据（最初时，指向第一条数据前面）
                {
                    Console.WriteLine(reader["StuNo"].ToString() + "\t" + reader["StuName"].ToString()) ;
                }
            }
            reader.Close();
            conn.Close();
        }

        public static void SelectTest2()
        {
            SqlConnection conn = new SqlConnection(builder.ConnectionString);

            //SqlCommand cmd = new SqlCommand();
            //cmd.Connection = conn;
            //cmd.CommandText = "SELECT COUNT(*) FROM Student";
            //SqlDataAdapter adapter = new SqlDataAdapter(cmd);//adapter会自动管理conn的开关，不需要手动打开和关闭
            //DataSet ds = new DataSet();//存数据的仓库
            //adapter.Fill(ds);//adapter搬运数据回来，放到本地仓库（放到了DataSet里面的第0号DataTable）

            //Console.WriteLine("共"+ds.Tables[0].Rows[0][0]+"名同学。");

            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "SELECT COUNT(*) FROM Student";
            int result = Convert.ToInt32(cmd.ExecuteScalar());
            conn.Close();
            Console.WriteLine(result+"人！！！！");
        }
    }
}
