﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wangv.CodeFirst.Models;
using Microsoft.Extensions.Logging; //LoggerFactory
using Microsoft.Extensions.Logging.Console; //AddConsole

namespace Wangv.CodeFirst
{
    public class WangvDBContext : DbContext
    {
        public DbSet<Blog> Blogs { get; set; }
        public DbSet<Post> Posts { get; set; }

        //父类的访问修饰符是protected
        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            builder.UseSqlServer("Data Source=.;User ID=sa;pwd=as;Initial Catalog=Test2;");

            builder.UseLoggerFactory(LoggerFactory.Create(lb => lb.AddConsole()));
        }

    }
}
