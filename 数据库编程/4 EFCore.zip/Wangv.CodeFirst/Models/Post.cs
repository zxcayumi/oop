﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wangv.CodeFirst.Models
{
    [Table("Post")]
    public class Post
    {
        public int PostId { get; set; }  //**Id自动识别为主键(自增编号)
        public string Title { get; set; }
        public string Content { get; set; }

        public int BlogId { get; set; } //外键
        public Blog Blog { get; set; }  //外键对应的实体
    }
}
