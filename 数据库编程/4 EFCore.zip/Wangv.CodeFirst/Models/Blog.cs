﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wangv.CodeFirst.Models
{
    [Table("Blog")]
    public class Blog
    {
        [Key]
        public int BlogId { get; set; } //**Id自动识别为主键

        [MaxLength(250)]
        public string Url { get; set; }

        [MaxLength(500)]
        public String Memo { get; set; }

        public List<Post> Posts { get; } = new List<Post>();
    }
}
