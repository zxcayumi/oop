﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Wangv.CodeFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            #region 增删改
            using (WangvDBContext ctx = new WangvDBContext())
            {
                //var blog = new Models.Blog
                //{
                //    Url = "https://www.sina.com.cn",
                //    Memo = "新浪欢迎欢迎!"
                //};
                //Console.WriteLine("Add操作前的状态："+ctx.Entry(blog).State);
                ////ctx.Blogs.Add(blog);//并不是向数据库添加信息，而是改变对象的状态
                //ctx.Entry(blog).State = EntityState.Added;
                //Console.WriteLine("Add操作后的状态："+ctx.Entry(blog).State);

                //ctx.SaveChanges();

                //先查询，再修改。
                //var blog = ctx.Blogs.FirstOrDefault(b => b.BlogId == 1);
                //Console.WriteLine("刚查询出的状态：" + ctx.Entry(blog).State);
                //var blog = new Models.Blog
                //{
                //    BlogId = 1,
                //    Memo = "没经过查询，我就修改了!"
                //};//Detached

                //ctx.Blogs.Update(blog);//方式1：改变状态为Modified
                ////ctx.Entry(blog).State = EntityState.Modified;//方式2：直接赋值相关状态
                //Console.WriteLine("Memo赋值后的状态：" + ctx.Entry(blog).State);

                //ctx.SaveChanges();//回写数据库，数据库持久化

                //var blog = new Models.Blog
                //{
                //    Url = "https://www.sina.com.cn",
                //    Memo = "11111!"
                //};
                //ctx.Blogs.Add(blog);

                //var blog1 = new Models.Blog
                //{
                //    Url = "https://www.sina.com.cn",
                //    Memo = "2222!"
                //};
                //ctx.Blogs.Add(blog1);

                //var blog2 = new Models.Blog
                //{
                //    Url = "https://www.sina.com.cn",
                //    Memo = "新浪欢迎欢迎!dkslfjdslkfjdslkfjlkdsjflkdskjfdsjflkdsjflkdsjfkds"
                //};
                //ctx.Blogs.Add(blog2);

                //ctx.SaveChanges();
            }
            #endregion

            #region 事务
            /*
            using WangvDBContext c = new WangvDBContext();
            using (var tran = c.Database.BeginTransaction())
            {
                try
                {
                    var blog = new Models.Blog
                    {
                        Url = "https://www.sina.com.cn",
                        Memo = "11111!"
                    };
                    c.Blogs.Add(blog);
                    c.SaveChanges();

                    var blog1 = new Models.Blog
                    {
                        Url = "https://www.sina.com.cn",
                        Memo = "2222!"
                    };
                    c.Blogs.Add(blog1);
                    c.SaveChanges();

                    var blog2 = new Models.Blog
                    {
                        Url = "https://www.sina.com.cn",
                        Memo = "新浪欢迎欢迎!dkslfjdslkfjdslkfjlkdsjflkdskjfdsjflkdsjflkdsjfkds"
                    };
                    c.Blogs.Add(blog2);
                    c.SaveChanges();

                    tran.Commit();//事务提交
                    Console.WriteLine("提交成功");
                }
                catch
                {
                    tran.Rollback();//所有的全部回滚，不写入数据库
                    Console.WriteLine("事务回滚，提交失败");
                }
            }*/
            #endregion

            using (var ctx = new WangvDBContext())
            {
                //var blog = ctx.Blogs.Where(b => b.BlogId == 200).FirstOrDefault();
                //if(blog != null)
                //    Console.WriteLine($"{blog.BlogId},{blog.Url},{blog.Memo}");

                ////模糊查询
                //List<Models.Blog> blogs = ctx.Blogs.Where(b => b.Memo.Contains("欢迎")).ToList();
                //foreach (var item in blogs)
                //{
                //    Console.WriteLine($"{item.BlogId},{item.Url},{item.Memo}");
                //}

                //var first = ctx.Blogs.Where(b => b.Memo.Contains("欢迎")).AsNoTracking().FirstOrDefault();

                //Console.WriteLine("-----------------------------------");
                //IQueryable blogs1 = ctx.Blogs.Where(b => b.Memo.Contains("欢迎"));
                //foreach (Models.Blog item in blogs1)
                //{
                //    Console.WriteLine($"{item.BlogId},{item.Url},{item.Memo}");
                //}

                //int[] ids = { 1, 3, 5 };
                //var results = ctx.Blogs.Where(b => ids.Contains(b.BlogId))
                //    .OrderByDescending(b => b.BlogId)
                //    .Select(b => new { Url = b.Url });
                //foreach (var item in results)
                //{
                //    Console.WriteLine($"{item}");
                //}

                int pageIndex = 2;//第2页
                int pageSize = 5;//每页5条数据
                var results = ctx.Blogs.Skip((pageIndex - 1) * pageSize).Take(pageSize);
                foreach (var m in results)
                {
                    Console.WriteLine(m.BlogId);
                }

                var blogs = ctx.Blogs.Where(b => b.BlogId == 1)
                    .Include(b => b.Posts).ToList();

                //执行原始SQL(增删改功能)，返回受影响的函数
                //int result = ctx.Database.ExecuteSqlRaw("INSERT  UPDATE DELETE");

                var blogs2 = ctx.Blogs.FromSqlRaw("select * from Blog").ToList();
            }
        }
    }
}
