﻿using System;
using System.Linq;

namespace Wangv.DBFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            using (Context.WangvContext ctx = new Context.WangvContext())
            {
                //Models.Blog b = new Models.Blog
                //{
                //    Url = "http://www.baidu.com"
                //};
                //ctx.Blogs.Add(b);
                //ctx.SaveChanges();
                //Console.WriteLine("添加成功");

                //var blog = ctx.Blogs.FirstOrDefault(b => b.BlogId == 1);
                //Console.WriteLine($"{blog.BlogId},{blog.Url}");

                //blog.Url = "http://www.sina.com.cn";
                //ctx.SaveChanges();

                var blog = ctx.Blogs.FirstOrDefault(b => b.BlogId == 2);
                Console.WriteLine($"{blog.BlogId},{blog.Url}");
                ctx.Blogs.Remove(blog);
                ctx.SaveChanges();
                Console.WriteLine("删除操作完成！");
            }
        }
    }
}
