﻿using System;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String stuNo = txtStuNo.Text;
            String stuName = txtStuName.Text;
            String birthday = dtpBirthday.Value.ToString("yyyy-MM-dd") ;

            using (SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=Test;User ID=sa;Password=as;Pooling=False"))
            {
                conn.Open();
                try
                {
                    //构造命令，并执行命令，完成添加操作
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = $"INSERT INTO Student(StuNo,StuName,Birthday) VALUES('{stuNo}','{stuName}','{birthday}')";

                    int count = cmd.ExecuteNonQuery();
                    if (count > 0) MessageBox.Show("添加成功");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int i = 1;
            String stuNo = i.ToString();//.PadLeft(5, '0');
            MessageBox.Show(stuNo);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Random rd = new Random();
            int num = rd.Next(0,5);//[0,5),随机产生一个整数 0，1，2，3，4
            MessageBox.Show(num.ToString());
        }
    }
}
