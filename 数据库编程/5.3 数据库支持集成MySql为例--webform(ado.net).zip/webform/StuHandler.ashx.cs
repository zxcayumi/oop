﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using MySql.Data.MySqlClient;

namespace webform
{
    /// <summary>
    /// StuHandler 的摘要说明
    /// </summary>
    public class StuHandler : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";//json、xml、html

            String stuNo = context.Request["StuNo"];
            String stuName = context.Request["StuName"];
            String sex = context.Request["Sex"];
            String birthday = context.Request["Birthday"];

            String sql = $"INSERT INTO Student(StuNo,StuName,Sex,Birthday) VALUES('{stuNo}','{stuName}','{sex}','{birthday}')";

            try
            {
                String connString = ConfigurationManager.ConnectionStrings["Default"].ToString();
                MySqlConnection conn = new MySqlConnection(connString);
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                context.Response.Write("添加成功");
            }
            catch
            {
                context.Response.Write("添加失败"); 
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}