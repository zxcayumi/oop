﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Web;

namespace webform
{
    /// <summary>
    /// StuHandler1 的摘要说明
    /// </summary>
    public class StuHandler1 : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            String keyword = context.Request["Keywords"];

            String sql = $"SELECT * FROM Student WHERE StuName LIKE '%{keyword}%'";
            String connString = ConfigurationManager.ConnectionStrings["Default"].ToString();
            MySqlConnection conn = new MySqlConnection(connString);
            MySqlDataAdapter adapter = new MySqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            adapter.Fill(ds);

            String html = "";
            html += "<table>";
            html += "<td>学号</td><td>姓名</td><td>性别</td><td>出生日期</td>";
            foreach (DataRow item in ds.Tables[0].Rows)
            {
                html += "<tr>";
                html += $"<td>{item["StuNo"].ToString()}</td><td>{item["StuName"].ToString()}</td>";
                html += $"<td>{item["Sex"].ToString()}</td><td>{item["Birthday"].ToString()}</td>";
                html += "</tr>";
            }
            html += "</table>";
            context.Response.Write(html);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}