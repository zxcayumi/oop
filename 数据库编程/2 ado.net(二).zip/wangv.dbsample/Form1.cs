﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace wangv.dbsample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            #region 非参数化
            //String memberName = txtMemberName.Text;
            //String password = txtPassword.Text;

            //String sql = $"SELECT COUNT(*) FROM Member WHERE MemberName='{memberName}' AND Password='{password}'";
            ////0.连接字符串
            //SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            //builder.DataSource = ".";
            //builder.InitialCatalog = "Test1";
            //builder.UserID = "sa";
            //builder.Password = "as";
            //String connectoinString = builder.ConnectionString;

            ////1.创建Connection
            //SqlConnection conn = new SqlConnection(connectoinString);

            ////2.构造Command
            //SqlCommand cmd = new SqlCommand();
            //cmd.CommandText = sql;
            //cmd.Connection = conn;

            ////3.执行命令
            //conn.Open();
            //Object obj = cmd.ExecuteScalar();
            //int result = Convert.ToInt32(obj);
            //if (result > 0)
            //    MessageBox.Show("身份验证成功");
            //else
            //    MessageBox.Show("身份验证失败");

            //conn.Close();
            #endregion

            #region 参数化查询
            String memberName = txtMemberName.Text;
            String password = txtPassword.Text;

            //0.连接字符串
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = ".";
            builder.InitialCatalog = "Test1";
            builder.UserID = "sa";
            builder.Password = "as";
            String connectoinString = builder.ConnectionString;

            //1.创建Connection
            SqlConnection conn = new SqlConnection(connectoinString);

            //2.构造Command（参数化的主要变化）
            String sql = $"SELECT COUNT(*) FROM Member WHERE MemberName=@MemberName AND Password=@Password";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = sql;
            cmd.Connection = conn;
            SqlParameter p0 = new SqlParameter("@MemberName", SqlDbType.NVarChar, 50);
            p0.Value = memberName;
            SqlParameter p1 = new SqlParameter("@Password", SqlDbType.NVarChar, 250);
            p1.Value = password;
            cmd.Parameters.Add(p0);
            cmd.Parameters.Add(p1);

            //3.执行命令
            conn.Open();
            Object obj = cmd.ExecuteScalar();
            int result = Convert.ToInt32(obj);
            if (result > 0)
                MessageBox.Show("身份验证成功");
            else
                MessageBox.Show("身份验证失败");

            conn.Close();
            #endregion
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            String memberName = txtMemberName.Text;
            String password = txtPassword.Text;

            //0.连接字符串
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = ".";
            builder.InitialCatalog = "Test1";
            builder.UserID = "sa";
            builder.Password = "as";
            String connectoinString = builder.ConnectionString;

            //1.创建Connection
            SqlConnection conn = new SqlConnection(connectoinString);

            //2.构造Command（参数化的主要变化）
            String sql = $"INSERT INTO Member(MemberName,Password) VALUES(@MemberName,@Password)";
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = sql;
            cmd.Connection = conn;
            SqlParameter p0 = new SqlParameter("@MemberName", SqlDbType.NVarChar, 50);
            p0.Value = memberName;
            SqlParameter p1 = new SqlParameter("@Password", SqlDbType.NVarChar, 250);
            p1.Value = password;
            cmd.Parameters.Add(p0);
            cmd.Parameters.Add(p1);

            //3.执行命令
            conn.Open();
            int result = cmd.ExecuteNonQuery();
            if (result > 0)
                MessageBox.Show("数据添加成功");
            else
                MessageBox.Show("数据添加失败");

            conn.Close();
        }

        private void btnTrans_Click(object sender, EventArgs e)
        {
            //0.连接字符串
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = ".";
            builder.InitialCatalog = "Test1";
            builder.UserID = "sa";
            builder.Password = "as";
            String connectoinString = builder.ConnectionString;

            //1.创建Connection
            SqlConnection conn = new SqlConnection(connectoinString);

            //事务操作
            conn.Open();
            SqlTransaction tran = conn.BeginTransaction();

            try
            {
                //张三：-3000
                String sql1 = "UPDATE Account SET Balance = Balance - 3000 WHERE CardNo = '00001'";
                SqlCommand cmd1 = new SqlCommand();
                cmd1.Transaction = tran;//指明当前命令所处的事务
                cmd1.Connection = conn;
                cmd1.CommandText = sql1;
                cmd1.ExecuteNonQuery();

                //李四：+3000
                String sql2 = "UPDATE Account SET Balance = Balance + 3000 WHERE CardNo = '00002'";
                SqlCommand cmd2 = new SqlCommand();
                cmd2.Transaction = tran;//指明当前命令所处的事务
                cmd2.Connection = conn;
                cmd2.CommandText = sql2;
                cmd2.ExecuteNonQuery();

                tran.Commit();//若全部成功，把所有命令提交数据库，持久化变化（全成功）
                MessageBox.Show("转账成功！");
            }
            catch
            {
                tran.Rollback();//若有错误，所有命令全部回滚，变回到最初状态（全失败）
                MessageBox.Show("转账失败！");
            }

            conn.Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //0.连接字符串
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = ".";
            builder.InitialCatalog = "Test1";
            builder.UserID = "sa";
            builder.Password = "as";
            String connectoinString = builder.ConnectionString;

            //1.创建Connection
            SqlConnection conn = new SqlConnection(connectoinString);

            //2.创建查询Command
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT * FROM Member WHERE MemberName LIKE '@MemberName%'";//查询多条信息
            cmd.Connection = conn;
            SqlParameter p = new SqlParameter("@MemberName", SqlDbType.NVarChar, 50);
            p.Value = "张";
            cmd.Parameters.Add(p);

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);

            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //0.连接字符串
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = ".";
            builder.InitialCatalog = "Test1";
            builder.UserID = "sa";
            builder.Password = "as";
            String connectoinString = builder.ConnectionString;

            //1.创建Connection
            SqlConnection conn = new SqlConnection(connectoinString);

            conn.Open();
            //2.创建Command
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "ProCount";//存储过程名称
            Object obj = cmd.ExecuteScalar();
            conn.Close();

            MessageBox.Show(obj.ToString());

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //0.连接字符串
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = ".";
            builder.InitialCatalog = "Test1";
            builder.UserID = "sa";
            builder.Password = "as";
            String connectoinString = builder.ConnectionString;

            //1.创建Connection
            SqlConnection conn = new SqlConnection(connectoinString);

            //2.创建Command
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "ProInsert";

            //3.初始化参数
            SqlParameter p0 = new SqlParameter("@MemberName", SqlDbType.NVarChar, 50);
            p0.Value = "user01";
            SqlParameter p1 = new SqlParameter("@Password", SqlDbType.NVarChar, 250);
            p1.Value = "654321";
            cmd.Parameters.Add(p0);
            cmd.Parameters.Add(p1);

            //4.执行命令
            conn.Open();
            int result = cmd.ExecuteNonQuery();
            conn.Close();

            if (result > 0)
            {
                MessageBox.Show("存储过程添加数据成功");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //0.连接字符串
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = ".";
            builder.InitialCatalog = "Test1";
            builder.UserID = "sa";
            builder.Password = "as";
            String connectoinString = builder.ConnectionString;

            //1.创建Connection
            SqlConnection conn = new SqlConnection(connectoinString);

            //2.创建Command
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "ProSearch";

            //3.初始化参数
            SqlParameter p0 = new SqlParameter("@MemberName", SqlDbType.NVarChar, 50);
            p0.Value = "user01";//参数默认都是输入参数
            SqlParameter p1 = new SqlParameter("@Password", SqlDbType.NVarChar, 250);
            p1.Direction = ParameterDirection.Output;//指明参数的方向（输出参数）
            cmd.Parameters.Add(p0);
            cmd.Parameters.Add(p1);

            //4.执行命令
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            MessageBox.Show("密码为："+p1.Value.ToString());
        }
    }
}
